# StageGate: Challenge 3 Submission

Multi-Turn Workflow Optimization for the Mavericks TalentVerse AI Token Optimization Arena. Open `index.html` in a browser for the interactive dashboard (editable assumptions, copy buttons, download of this document).

The original one-shot request (337 characters, about 84 estimated tokens) is replaced by a 7-stage verified workflow.

## Staged workflow

### Stage 1: Discovery
- Input: Repo map, current errors, product requirements
- Output: Architecture summary, risks, dependencies, ordered plan (no code changes)
- Gate: Scope and protected behavior approved

### Stage 2: Contracts and data
- Input: Approved plan, relevant API and schema files
- Output: API contracts and development schema changes
- Gate: Code generation and schema checks pass

### Stage 3: Authentication (high risk)
- Input: Project contract, auth files, API contracts
- Output: Migrated authentication flow
- Gate: Sign-in, sign-out, session refresh and protected routes pass

### Stage 4: Catalog
- Input: Catalog contracts and files
- Output: Product management, search and filtering changes
- Gate: List, search, filter and CRUD checks pass

### Stage 5: Checkout and payments (high risk)
- Input: Checkout and payment contracts and files
- Output: Test-mode checkout and payment integration
- Gate: Success, decline, retry, cancellation, webhook and idempotency checks pass

### Stage 6: Interface and accessibility
- Input: Completed feature surfaces
- Output: Integrated interface and accessibility corrections
- Gate: Keyboard, labels, focus and responsive checks pass

### Stage 7: Release verification
- Input: Short summaries and changed-file lists from earlier stages
- Output: Regression results, performance findings, release checklist, deployment plan
- Gate: All required checks pass before anything is published

## Reusable context contract
```
PROJECT CONTRACT (v1)
1. Stack: use the existing stack and project patterns; add no new dependency without approval.
2. Security: validate all external input; never expose or log secrets, tokens or cookies.
3. Behavior: preserve existing supported behavior and accessibility.
4. Scope: work on the current stage only; one primary outcome per stage.
5. Checks: run type, test and build checks before finishing.
6. Report: list changed files, decisions made and verification results.
7. Gate: do not start a stage until its required earlier gates have passed.
```

## Context handoff template
```
HANDOFF: Stage <N> - <name>
Contract: PROJECT CONTRACT v1
Goal: <one primary outcome>
Prior result: <2-3 line summary of last stage>
Evidence: <gate results, e.g. tests passed>
Decisions: <choices already made, do not reopen>
Open items: <unresolved questions>
Files: <only this stage's files and contracts>
Output needed: <deliverable + gate to pass>
```

## Token comparison (estimated tokens = characters / 4)
Assumptions: repo 50000, history growth 2000 per stage, discovery 8000, stage files 6000, handoff 200, contract 139.25 once plus 7 per reference.

| Approach | Tokens |
|---|---|
| Naive multi-turn (resend repo and history each stage) | 392000 |
| Staged workflow | 45381 |
| One-shot with 2 retries | 150000 |

- Reduction vs naive multi-turn: 88.4%
- Reduction vs one-shot with 2 retries: 69.7%
- A single successful one-shot pass (50000) is cheap; the saving comes from avoiding retries and resent history.
- Contract: 975 tokens if pasted in all 7 stages vs 181 written once.

## Token-saving and quality explanation
- Bounded goal: each turn has one outcome, so no requirement is lost among ten.
- Isolated high-risk work: authentication and payments have dedicated gates.
- Early failure detection: a bad stage is caught at its gate, before later work depends on it.
- Written once: the contract keeps rules consistent instead of repeating them every prompt.
- Evidence travels: handoffs carry gate results and decisions, never the full history.
